package test;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import model.Comentario;
import service.ComentarioService;

public class ComentarioTest {
	Comentario comentario, copy;
	ComentarioService comentarioService;
	static int id = 0;

	/*
	 * Antes de rodar este teste, certifique-se que nao ha no banco nenhuma
	 * linha com o id igual ao do escolhido para o to instanciado abaixo. Se
	 * houver, delete. 
	 * Certifique-se tamb�m que sobrecarregou o equals na classe
	 * Cliente. 
	 * Certifique-se que a fixture cliente1 foi criada no banco.
	 * Al�m disso, a ordem de execu��o dos testes � importante; por
	 * isso a anota��o FixMethodOrder logo acima do nome desta classe
	 */
	@Before
	public void setUp() throws Exception {
		System.out.println("setup");
		comentario = new Comentario();
		comentario.setId_Comentario(id);
		comentario.setNome("Batista Cepelos");
		comentario.setFone("(11) 91234-4321");
		comentario.setEmail("(11) 91234-4321");
		copy = new Cliente();
		copy.setId(id);
		copy.setNome("Batista Cepelos");
		copy.setFone("(11) 91234-4321");
		copy.setEmail("(11) 91234-4321");
		comentarioService = new comentarioService();
		System.out.println(comentario);
		System.out.println(copy);
		System.out.println(id);
	}
	
	@Test
	public void test00Carregar() {
		System.out.println("carregar");
		//para funcionar o cliente 1 deve ter sido carregado no banco por fora
		Cliente fixture = new Cliente();
		fixture.setId(1);
		fixture.setNome("Carlos Drummond de Andrade");
		fixture.setFone("(11) 91234-4321");
		fixture.setEmail("cda@usjt.br");
		ClienteService novoService = new ClienteService();
		Cliente novo = novoService.carregar(1);
		assertEquals("testa inclusao", novo, fixture);
	}

	@Test
	public void test01Criar() {
		System.out.println("criar");
		id = clienteService.criar(cliente);
		System.out.println(id);
		copia.setId(id);
		assertEquals("testa criacao", cliente, copia);
	}

	@Test
	public void test02Atualizar() {
		System.out.println("atualizar");
		cliente.setFone("999999");
		copia.setFone("999999");		
		clienteService.atualizar(cliente);
		cliente = clienteService.carregar(cliente.getId());
		assertEquals("testa atualizacao", cliente, copia);
	}

	@Test
	public void test03Excluir() {
		System.out.println("excluir");
		copia.setId(-1);
		copia.setNome(null);
		copia.setFone(null);
		copia.setEmail(null);
		clienteService.excluir(id);
		cliente = clienteService.carregar(id);
		assertEquals("testa exclusao", cliente, copia);
	}
}
