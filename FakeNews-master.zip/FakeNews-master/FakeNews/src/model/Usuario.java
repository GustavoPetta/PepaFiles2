package model;

public class Usuario {
	private int id_Usuario;
	private String email_Usuario;
	private String nome;
	private String senha;
	private String perfil;
	public int getId_Usuario() {
		return id_Usuario;
	}
	public void setId_Usuario(int id_Usuario) {
		this.id_Usuario = id_Usuario;
	}
	public String getEmail_Usuario() {
		return email_Usuario;
	}
	public void setEmail_Usuario(String email_Usuario) {
		this.email_Usuario = email_Usuario;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getSenha() {
		return senha;
	}
	public void setSenha(String senha) {
		this.senha = senha;
	}
	public String getPerfil() {
		return perfil;
	}
	public void setPerfil(String perfil) {
		this.perfil = perfil;
	}
	@Override
	public String toString() {
		return "Usuario [id_Usuario=" + id_Usuario + ", email_Usuario=" + email_Usuario + ", nome=" + nome + ", senha="
				+ senha + ", perfil=" + perfil + "]";
	}
	
	
}
