package model;

public class Noticia {
	private int id_Noticia;
	private String titulo;
	private String texto_Noticia;
	private String resumo;
	public int getId_Noticia() {
		return id_Noticia;
	}
	public void setId_Noticia(int id_Noticia) {
		this.id_Noticia = id_Noticia;
	}
	public String getTitulo() {
		return titulo;
	}
	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}
	public String getTexto_Noticia() {
		return texto_Noticia;
	}
	public void setTexto_Noticia(String texto_Noticia) {
		this.texto_Noticia = texto_Noticia;
	}
	public String getResumo() {
		return resumo;
	}
	public void setResumo(String resumo) {
		this.resumo = resumo;
	}
	@Override
	public String toString() {
		return "Noticia [id_Noticia=" + id_Noticia + ", titulo=" + titulo + ", texto_Noticia=" + texto_Noticia
				+ ", resumo=" + resumo + "]";
	}
	
	
}
