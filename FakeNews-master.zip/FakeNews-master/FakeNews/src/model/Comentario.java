package model;

public class Comentario {
	private int id_Comentario;
	private int id_Usuario;
	private String email_Usuario;
	private int id_Noticia;
	private String texto_Comentario;
	public int getId_Comentario() {
		return id_Comentario;
	}
	public void setId_Comentario(int id_Comentario) {
		this.id_Comentario = id_Comentario;
	}
	public int getId_Usuario() {
		return id_Comentario;
	}
	public void setId_Usuario(int id_Usuario) {
		this.id_Usuario = id_Usuario;
	}
	public String getEmail_Usuario() {
		return email_Usuario;
	}
	public void setEmail_Usuario(String email_Usuario) {
		this.email_Usuario = email_Usuario;
	}
	public int getId_Noticia() {
		return id_Noticia;
	}
	public void setId_Noticia(int id_Noticia) {
		this.id_Noticia = id_Noticia;
	}
	public String getTexto() {
		return texto_Comentario;
	}
	public void setTexto(String texto_Comentario) {
		this.texto_Comentario = texto_Comentario;
	}
	@Override
	public String toString() {
		return "Comentario [id_Comentario=" + id_Comentario + ", id_Usuario=" + id_Usuario + ", email_Usuario="
				+ email_Usuario + ", id_Noticia=" + id_Noticia + ", texto_Comentario=" + texto_Comentario + "]";
	}
	
}
