package service;

import dao.ComentarioDAO;
import model.Comentario;

public class ComentarioService {
ComentarioDAO dao = new ComentarioDAO();
	
	public int criar(Comentario comentario) {
		return dao.criar(comentario);
	}
	
	/*public void atualizar(Comentario Comentario){
		dao.atualizar(Comentario);
	}*/
	
	public void excluir(int id){
		dao.excluir(id);
	}
	
	/*public Cliente carregar(int id){
		return dao.carregar(id);
	}*/

}
