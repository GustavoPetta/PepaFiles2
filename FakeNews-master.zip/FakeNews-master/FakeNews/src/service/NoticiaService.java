package service;

import dao.NoticiaDAO;
import model.Noticia;

public class NoticiaService {
NoticiaDAO dao = new NoticiaDAO();
	
	public int criar(Noticia noticia) {
		return dao.criar(noticia);
	}
	
	public void atualizar(Noticia noticia){
		dao.atualizar(noticia);
	}
	
	public void excluir(int id){
		dao.excluir(id);
	}
	
	/*public Cliente carregar(int id){
		return dao.carregar(id);
	}*/
}
